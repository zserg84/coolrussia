<?php

return [
    'QUESTION_WHERE' => 'Where will we go?',
    'QUESTION_INCLUDE_IN_PRICE' => 'What is included in the price?',
    'QUESTION_TAKE' => 'What to bring?',
    'QUESTION_WHY' => 'Why should go here?',
    'QUESTION_WHAT' => 'What will we do?',
    'QUESTION_EXTRA' => 'Extra',
    'QUESTION_DESCRIPTION' => 'Description',
];