<?php

return [
    'QUESTION_WHERE' => 'Куда пойдём?',
    'QUESTION_INCLUDE_IN_PRICE' => 'Что входит в стоимость?',
    'QUESTION_TAKE' => 'Что взять с собой?',
    'QUESTION_WHY' => 'Почему сюда стоит сходить?',
    'QUESTION_WHAT' => 'Что будем делать?',
    'QUESTION_EXTRA' => 'Дополнительно',
    'QUESTION_DESCRIPTION' => 'Описание',

    '{attribute} can not be blank' => 'Вы должны заполнить поле "{attribute}"',
];